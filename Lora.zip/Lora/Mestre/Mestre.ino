#include <SPI.h>
#include <LoRa.h>

// Pinos LoRa - Heltec WiFi LoRa 32 V2
#define LORA_SCK   5
#define LORA_MISO  19
#define LORA_MOSI  27
#define LORA_SS    18
#define LORA_RST   14
#define LORA_DIO0  26

#define FREQUENCY 915E6 // Frequencia LoRa, isso é padrão turma, não modifiquem

void setup() {
  Serial.begin(115200);
  delay(1500);

  Serial.println();
  Serial.println("================================");
  Serial.println("       ESP32 - MESTRE LoRa");
  Serial.println("================================");

  // Inicializa comunicacao SPI
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);

  // Configura os pinos do LoRa
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);

  Serial.println("Inicializando LoRa...");

  if (!LoRa.begin(FREQUENCY)) {
    Serial.println("ERRO: LoRa nao inicializou!");
    while (true) {
      delay(1000);
    }
  }

  Serial.println("LoRa inicializado!");
  Serial.println("Frequencia: 915 MHz");
  Serial.println();
  Serial.println("Digite ligar ou desligar:");
}

void loop() {
  if (Serial.available() > 0) {
    String mensagem = Serial.readStringUntil('\n');

    mensagem.trim();
    mensagem.toLowerCase();

    if (mensagem.length() == 0) {
      return;
    }

    Serial.print("Comando digitado: ");
    Serial.println(mensagem);

    if (mensagem != "ligar" && mensagem != "desligar") {
      Serial.println("Comando invalido. Digite ligar ou desligar.");
      return;
    }

    Serial.println("Transmitindo pelo LoRa...");

    LoRa.beginPacket();
    LoRa.print(mensagem);
    int resultado = LoRa.endPacket();

    if (resultado == 1) {
      Serial.println("Transmissao concluida!");
      Serial.print("Comando enviado: ");
      Serial.println(mensagem);
    } else {
      Serial.println("ERRO: falha na transmissao!");
    }

    Serial.println("-------------------------------");
  }
}