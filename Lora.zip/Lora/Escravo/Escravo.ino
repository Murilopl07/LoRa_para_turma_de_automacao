#include <SPI.h>
#include <LoRa.h>

// Pinos LoRa - Heltec WiFi LoRa 32 V2
#define LORA_SCK   5
#define LORA_MISO  19
#define LORA_MOSI  27
#define LORA_SS    18
#define LORA_RST   14
#define LORA_DIO0  26

// LED conectado ao GPIO 2
#define LED_PIN 2

// Frequencia LoRa, isso é padrão turma, não modifiquem
#define FREQUENCY 915E6

void setup() {
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println("     ESP32 - ESCRAVO LoRa");
  Serial.println("================================");

  // Configura o LED
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // Configura SPI
  SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_SS);

  // Configura os pinos LoRa
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);

  Serial.println("Inicializando LoRa...");

  if (!LoRa.begin(FREQUENCY)) {
    Serial.println("ERRO: LoRa nao inicializou!");

    while (true) {
      delay(1000);
    }
  }

  Serial.println("LoRa inicializado!");
  Serial.println("Frequencia: 915 MHz");
  Serial.println("Aguardando comandos do mestre...");
  Serial.println();
}

void loop() {
  int tamanhoPacote = LoRa.parsePacket();

  if (tamanhoPacote) {
    String mensagem = "";

    while (LoRa.available()) {
      mensagem += (char)LoRa.read();
    }

    mensagem.trim();
    mensagem.toLowerCase();

    Serial.print("Mensagem recebida: ");
    Serial.println(mensagem);

    if (mensagem == "ligar") {
      digitalWrite(LED_PIN, HIGH);
      Serial.println("LED LIGADO!");
    }
    else if (mensagem == "desligar") {
      digitalWrite(LED_PIN, LOW);
      Serial.println("LED DESLIGADO!");
    }
    else {
      Serial.println("Comando desconhecido!");
    }

    Serial.println();
  }
}